package com.ejemplo.ganeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GaneapiApplication {
    public static void main(String[] args) {
        SpringApplication.run(GaneapiApplication.class, args);
    }
}
