package com.ejemplo.ganeapi.service;

import com.ejemplo.ganeapi.entity.Genero;
import com.ejemplo.ganeapi.repository.GeneroRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GeneroService {

    private final GeneroRepository repository;

    public GeneroService(GeneroRepository repository) {
        this.repository = repository;
    }

    public List<Genero> listar() {
        return repository.findAll();
    }

    public Genero obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Género no encontrado: " + id));
    }

    public Genero crear(Genero genero) {
        return repository.save(genero);
    }
}
