package com.ejemplo.ganeapi.repository;

import com.ejemplo.ganeapi.entity.Genero;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GeneroRepository extends JpaRepository<Genero, Long> {
    Optional<Genero> findByNombreIgnoreCase(String nombre);
}
