package com.ejemplo.ganeapi.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Map;

@Service
public class PokeApiService {

    private static final Logger log = LoggerFactory.getLogger(PokeApiService.class);
    private final RestClient restClient;

    public PokeApiService(RestClient restClient) {
        this.restClient = restClient;
    }

    public Map<String, Object> buscarPokemon(String nombre) {
        try {
            log.info("Consultando API externa PokeAPI para pokemon={}", nombre);
            return restClient.get()
                    .uri("/pokemon/{nombre}", nombre.toLowerCase().trim())
                    .retrieve()
                    .body(Map.class);
        } catch (RestClientException ex) {
            log.error("Error al consumir PokeAPI para pokemon={}: {}", nombre, ex.getMessage());
            throw new IllegalStateException("No fue posible consultar la API externa para: " + nombre);
        }
    }
}
