package com.ejemplo.ganeapi.service;

import com.ejemplo.ganeapi.entity.Genero;
import com.ejemplo.ganeapi.entity.Videojuego;
import com.ejemplo.ganeapi.repository.GeneroRepository;
import com.ejemplo.ganeapi.repository.VideojuegoRepository;
import io.micrometer.core.instrument.Counter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideojuegoService {

    private static final Logger log = LoggerFactory.getLogger(VideojuegoService.class);

    private final VideojuegoRepository videojuegoRepository;
    private final GeneroRepository generoRepository;
    private final Counter consultasCounter;

    public VideojuegoService(VideojuegoRepository videojuegoRepository,
                             GeneroRepository generoRepository,
                             Counter consultasCounter) {
        this.videojuegoRepository = videojuegoRepository;
        this.generoRepository = generoRepository;
        this.consultasCounter = consultasCounter;
    }

    public List<Videojuego> listar() {
        consultasCounter.increment();
        log.info("Consultando lista de videojuegos");
        return videojuegoRepository.findAll();
    }

    public Videojuego obtener(Long id) {
        consultasCounter.increment();
        log.info("Consultando videojuego con id={}", id);
        return videojuegoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Videojuego no encontrado: " + id));
    }

    public Videojuego crear(Videojuego videojuego, Long generoId) {
        Genero genero = generoRepository.findById(generoId)
                .orElseThrow(() -> new IllegalArgumentException("Género no encontrado: " + generoId));
        videojuego.setGenero(genero);
        Videojuego guardado = videojuegoRepository.save(videojuego);
        log.info("Videojuego creado con id={} y generoId={}", guardado.getId(), generoId);
        return guardado;
    }

    public Videojuego actualizar(Long id, Videojuego datos, Long generoId) {
        Videojuego actual = obtener(id);
        Genero genero = generoRepository.findById(generoId)
                .orElseThrow(() -> new IllegalArgumentException("Género no encontrado: " + generoId));

        actual.setTitulo(datos.getTitulo());
        actual.setDescripcion(datos.getDescripcion());
        actual.setAnioLanzamiento(datos.getAnioLanzamiento());
        actual.setGenero(genero);

        log.info("Videojuego actualizado con id={}", id);
        return videojuegoRepository.save(actual);
    }

    public void eliminar(Long id) {
        if (!videojuegoRepository.existsById(id)) {
            throw new IllegalArgumentException("Videojuego no encontrado: " + id);
        }
        videojuegoRepository.deleteById(id);
        log.warn("Videojuego eliminado con id={}", id);
    }

    public List<Videojuego> porGenero(Long generoId) {
        consultasCounter.increment();
        log.info("Consultando videojuegos del genero id={}", generoId);
        return videojuegoRepository.findByGeneroId(generoId);
    }
}
