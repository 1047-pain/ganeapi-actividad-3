package com.ejemplo.ganeapi.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class GaneapiHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        return Health.up()
                .withDetail("servicio", "GaneAPI")
                .withDetail("modulo", "Videojuegos")
                .withDetail("observabilidad", "Actuator + Micrometer")
                .build();
    }
}
