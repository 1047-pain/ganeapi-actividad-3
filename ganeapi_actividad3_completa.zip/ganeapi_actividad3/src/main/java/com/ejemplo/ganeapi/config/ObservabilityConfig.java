package com.ejemplo.ganeapi.config;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ObservabilityConfig {

    @Bean
    public Counter consultasVideojuegosCounter(MeterRegistry registry) {
        return Counter.builder("ganeapi.videojuegos.consultas")
                .description("Cantidad de consultas realizadas al recurso de videojuegos")
                .register(registry);
    }
}
