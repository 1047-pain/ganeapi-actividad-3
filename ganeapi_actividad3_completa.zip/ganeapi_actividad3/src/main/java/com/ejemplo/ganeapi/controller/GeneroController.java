package com.ejemplo.ganeapi.controller;

import com.ejemplo.ganeapi.entity.Genero;
import com.ejemplo.ganeapi.service.GeneroService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/generos")
public class GeneroController {

    private final GeneroService service;

    public GeneroController(GeneroService service) {
        this.service = service;
    }

    @GetMapping
    public List<Genero> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Genero obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Genero crear(@Valid @RequestBody Genero genero) {
        return service.crear(genero);
    }
}
