package com.ejemplo.ganeapi.controller;

import com.ejemplo.ganeapi.entity.Videojuego;
import com.ejemplo.ganeapi.service.PokeApiService;
import com.ejemplo.ganeapi.service.VideojuegoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/videojuegos")
public class VideojuegoController {

    private final VideojuegoService service;
    private final PokeApiService pokeApiService;

    public VideojuegoController(VideojuegoService service, PokeApiService pokeApiService) {
        this.service = service;
        this.pokeApiService = pokeApiService;
    }

    @GetMapping
    public List<Videojuego> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Videojuego obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @GetMapping("/genero/{generoId}")
    public List<Videojuego> porGenero(@PathVariable Long generoId) {
        return service.porGenero(generoId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Videojuego crear(@Valid @RequestBody Videojuego videojuego,
                            @RequestParam Long generoId) {
        return service.crear(videojuego, generoId);
    }

    @PutMapping("/{id}")
    public Videojuego actualizar(@PathVariable Long id,
                                 @Valid @RequestBody Videojuego videojuego,
                                 @RequestParam Long generoId) {
        return service.actualizar(id, videojuego, generoId);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    @GetMapping("/externa/pokemon/{nombre}")
    public Map<String, Object> pokemon(@PathVariable String nombre) {
        return pokeApiService.buscarPokemon(nombre);
    }
}
